﻿create TABLE KHACHHANG(
TenDN VARCHAR(30),
MatKhau VARCHAR(50),
TenKhachHang NVARCHAR(50),
CONSTRAINT Pk_TenDn PRIMARY KEY(TenDN)
)

create TABLE DANHMUCHOA(
MaDM CHAR(10),
TenDM NVARCHAR(50),
MoTa NVARCHAR(50),
CONSTRAINT Pk_MaDM PRIMARY KEY(MaDM)
)

CREATE TABLE HOA(
MaHoa CHAR(10),
TenHoa NVARCHAR(50),
DonViTinh NVARCHAR(20),
DonGia FLOAT,
HinhAnh VARCHAR(100),
MoTa NVARCHAR(50),
MaDM CHAR(10),
CONSTRAINT Pk_MaHoa PRIMARY KEY (MaHoa),
CONSTRAINT Fk_MaDM FOREIGN KEY (MaDM) REFERENCES DANHMUCHOA(MaDM)
)

CREATE TABLE DONHANG(
TenDN VARCHAR(30),
MaHoa CHAR(10),
SoLuong INT,
CONSTRAINT Pk_TenDN_MaHoa PRIMARY KEY(TenDN, MaHoa),
CONSTRAINT Fk_TenDN FOREIGN KEY (TenDN) REFERENCES KHACHHANG(TenDN),
CONSTRAINT Fk_MaHoa FOREIGN KEY (MaHoa) REFERENCES HOA(MaHoa),
CONSTRAINT Ch_SLH CHECK(SoLuong > 0),
)

-- Thêm dữ liệu vào bảng KHACHHANG
INSERT INTO KHACHHANG (TenDN, MatKhau, TenKhachHang)
VALUES
('user1', 'password123', N'Nguyễn Văn A'),
('user2', 'password456', N'Lê Thị B'),
('user3', 'password789', N'Trần Văn C');

-- Thêm dữ liệu vào bảng DANHMUCHOA
INSERT INTO DANHMUCHOA (MaDM, TenDM, MoTa)
VALUES
('DM001', N'Hoa Hồng', N'Các loại hoa hồng đẹp'),
('DM002', N'Hoa Cúc', N'Các loại hoa cúc đa dạng'),
('DM003', N'Hoa Lan', N'Hoa lan cao cấp');

-- Thêm dữ liệu vào bảng HOA
INSERT INTO HOA (MaHoa, TenHoa, DonViTinh, DonGia, HinhAnh, MoTa, MaDM)
VALUES
('H001', N'Hoa Hồng Đỏ', N'Cành', 50000, 'hongdo.jpg', N'Hoa hồng đỏ đẹp', 'DM001'),
('H002', N'Hoa Hồng Trắng', N'Cành', 45000, 'hongtrang.jpg', N'Hoa hồng trắng tinh khiết', 'DM001'),
('H003', N'Hoa Cúc Vàng', N'Cành', 30000, 'cucvang.jpg', N'Hoa cúc vàng tươi sáng', 'DM002'),
('H004', N'Hoa Lan Hồ Điệp', N'Chậu', 150000, 'lanhodiep.jpg', N'Hoa lan cao cấp', 'DM003');

-- Thêm dữ liệu vào bảng DONHANG
INSERT INTO DONHANG (TenDN, MaHoa, SoLuong)
VALUES
('user1', 'H001', 2),
('user2', 'H002', 3),
('user3', 'H003', 1),
('user1', 'H004', 1);

