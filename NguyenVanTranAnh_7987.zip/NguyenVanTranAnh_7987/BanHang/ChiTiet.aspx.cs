﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class ChiTiet : System.Web.UI.Page
    {
        KetNoi kn = new KetNoi();
        protected void Page_Load(object sender, EventArgs e)
        {
            string q;
            string MaHoa = Request.QueryString["MaHoa"];
            
            if (string.IsNullOrEmpty(MaHoa))
            {
                q = "select * from HOA";
            }
            else
            {
                q = "select * from HOA where MaHoa = '" + MaHoa + "'";
            }
            this.DataList1.DataSource = kn.laydulieu(q);
            this.DataList1.DataBind();
        }
    }
}