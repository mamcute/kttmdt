﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class BanHang : System.Web.UI.MasterPage
    {
        KetNoi kn = new KetNoi();

        protected void Page_Load(object sender, EventArgs e)
        {
            lblSoLuotTC.Text = Application["SoLuotTruyCap"].ToString();
            if (Page.IsPostBack) return;
            string q = "select * from DANHMUCHOA";

            this.DataList1.DataSource = kn.laydulieu(q);
            this.DataList1.DataBind();

        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            string MaDM = ((LinkButton)sender).CommandArgument;
            Response.Redirect($"SanPham.aspx?MaDM=" + MaDM);
        }
    }
}