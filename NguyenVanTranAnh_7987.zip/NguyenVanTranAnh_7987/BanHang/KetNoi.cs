﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace BanHang
{
    public class KetNoi

    {
        SqlConnection con;
        private void layketnoi()
        {
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\TRAN ANH\source\repos\BanHang\BanHang\App_Data\BanHoa.mdf;Integrated Security=True");
            con.Open();
        }
        private void dongketnoi()
        {
            if (con.State == ConnectionState.Open) ;
            con.Close();
        }
        public DataTable laydulieu(string sql)
        {
            DataTable dt = new DataTable();
            {
                try
                {
                    layketnoi();
                    SqlDataAdapter adap = new SqlDataAdapter(sql, con);
                    adap.Fill(dt);

                }
                catch
                {
                    dt = null;
                }
                finally
                {
                    dongketnoi();
                }
                return dt;
            }
        }
    }
}