﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BanHang
{
    public partial class SanPham : System.Web.UI.Page
    {
        KetNoi kn = new KetNoi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            string q;
            string MaDM = Request.QueryString["MaDM"];
            if (string.IsNullOrEmpty(MaDM))
                q = "select * from HOA";
            else
            {
                q = "select * from HOA where MaDM = '" + MaDM + "'";
            }

            this.DataList1.DataSource = kn.laydulieu(q);
            this.DataList1.DataBind();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            string MaHoa = ((LinkButton)sender).CommandArgument;
            Response.Redirect($"ChiTiet.aspx?MaHoa=" + MaHoa);
        }
    }
}